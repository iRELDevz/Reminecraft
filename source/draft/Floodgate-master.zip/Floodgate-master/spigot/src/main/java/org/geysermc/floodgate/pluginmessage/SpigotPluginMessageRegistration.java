/*
 * Copyright (c) 2019-2022 GeyserMC. http://geysermc.org
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author GeyserMC
 * @link https://github.com/GeyserMC/Floodgate
 */

package org.geysermc.floodgate.pluginmessage;

import lombok.RequiredArgsConstructor;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.Messenger;
import org.geysermc.floodgate.api.FloodgateApi;
import org.geysermc.floodgate.api.player.FloodgatePlayer;
import org.geysermc.floodgate.pluginmessage.PluginMessageChannel.Result;

@RequiredArgsConstructor
public class SpigotPluginMessageRegistration implements PluginMessageRegistration {
    private final JavaPlugin plugin;
    private final FloodgateApi api;

    @Override
    public void register(PluginMessageChannel channel) {
        Messenger messenger = plugin.getServer().getMessenger();

        messenger.registerIncomingPluginChannel(
                plugin,
                channel.getIdentifier(),
                (channel1, player, message) -> {
                    FloodgatePlayer fPlayer = api.getPlayer(player.getUniqueId());
                    if (fPlayer == null) {
                        player.kickPlayer("Only Floodgate players can send floodgate messages!");
                        return;
                    }

                    Result result = channel.handleServerCall(message, fPlayer);
                    if (!result.isAllowed() && result.getReason() != null) {
                        player.kickPlayer(result.getReason());
                    }
                });

        messenger.registerOutgoingPluginChannel(plugin, channel.getIdentifier());
    }
}
